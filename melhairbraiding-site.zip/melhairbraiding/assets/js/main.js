/* ============================================================
   MEL HAIR BRAIDING — Main JS
   ============================================================ */

// ── Nav scroll effect ──
const nav = document.querySelector('.nav');
if (nav) {
  window.addEventListener('scroll', () => {
    nav.classList.toggle('scrolled', window.scrollY > 50);
  });
}

// ── Mobile menu ──
const toggle = document.querySelector('.nav-toggle');
const navLinks = document.querySelector('.nav-links');
if (toggle && navLinks) {
  toggle.addEventListener('click', () => {
    navLinks.classList.toggle('open');
  });
  // Close on link click
  navLinks.querySelectorAll('a').forEach(a => {
    a.addEventListener('click', () => navLinks.classList.remove('open'));
  });
}

// ── Active nav link ──
const currentPage = location.pathname.split('/').filter(Boolean).pop() || 'index.html';
document.querySelectorAll('.nav-links a').forEach(a => {
  const href = a.getAttribute('href');
  if (href && href.includes(currentPage)) a.classList.add('active');
});

// ── Scroll reveal ──
const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach(e => {
    if (e.isIntersecting) {
      e.target.classList.add('visible');
      revealObserver.unobserve(e.target);
    }
  });
}, { threshold: 0.1, rootMargin: '0px 0px -60px 0px' });

document.querySelectorAll('.reveal').forEach(el => revealObserver.observe(el));

// ── Slider ──
function initSlider(sliderEl) {
  if (!sliderEl) return;
  const slides = sliderEl.querySelectorAll('.slide');
  const dotsContainer = sliderEl.querySelector('.slider-dots');
  const prevBtn = sliderEl.querySelector('.slider-arrow.prev');
  const nextBtn = sliderEl.querySelector('.slider-arrow.next');
  let current = 0;
  let timer;

  // Build dots
  if (dotsContainer) {
    slides.forEach((_, i) => {
      const dot = document.createElement('button');
      dot.className = 'slider-dot' + (i === 0 ? ' active' : '');
      dot.addEventListener('click', () => goTo(i));
      dotsContainer.appendChild(dot);
    });
  }

  function goTo(idx) {
    slides[current].classList.remove('active');
    dotsContainer && (dotsContainer.querySelectorAll('.slider-dot')[current].classList.remove('active'));
    current = (idx + slides.length) % slides.length;
    slides[current].classList.add('active');
    dotsContainer && (dotsContainer.querySelectorAll('.slider-dot')[current].classList.add('active'));
    resetTimer();
  }

  function resetTimer() {
    clearInterval(timer);
    timer = setInterval(() => goTo(current + 1), 5500);
  }

  slides[0].classList.add('active');
  if (prevBtn) prevBtn.addEventListener('click', () => goTo(current - 1));
  if (nextBtn) nextBtn.addEventListener('click', () => goTo(current + 1));
  if (slides.length > 1) resetTimer();

  // Touch swipe
  let startX = 0;
  sliderEl.addEventListener('touchstart', e => { startX = e.touches[0].clientX; }, { passive: true });
  sliderEl.addEventListener('touchend', e => {
    const diff = startX - e.changedTouches[0].clientX;
    if (Math.abs(diff) > 50) goTo(diff > 0 ? current + 1 : current - 1);
  });
}

document.querySelectorAll('.slider').forEach(initSlider);
